This project is written exclusively in c++

Dependencies :
    This project requires SFML 2.0 and can be downloaded using the package name "sfml-devel" using most package manager

The coordinates used to produce the graphical interface are from iledefrance-mobilites.fr
under the Etalab open Licence
    https://data.iledefrance-mobilites.fr/explore/dataset/emplacement-des-gares-idf/information/